from .diff import _diffn, _diffp, _diffm, _diffs, _diffsp
